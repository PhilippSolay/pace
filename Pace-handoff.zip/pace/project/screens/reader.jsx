// Reader screen — the centerpiece
function pinSplit(word) {
  const pinIdx = Math.ceil(word.length / 2) - 1;
  return {
    left: word.slice(0, pinIdx),
    pin: word[pinIdx] || '',
    right: word.slice(pinIdx + 1),
  };
}

function ReaderWord({ word, size = 52, glow = true }) {
  const { left, pin, right } = pinSplit(word);
  const pinRef = React.useRef(null);
  return (
    <div style={{
      position: 'absolute', top: '50%', left: '50%',
      transform: 'translate(0, -50%)',
      display: 'flex', alignItems: 'baseline',
      fontFamily: 'var(--font-reader)', fontWeight: 400,
      fontSize: size, color: 'var(--ink)', lineHeight: 1,
      letterSpacing: '0.005em',
    }}>
      {glow && (
        <div style={{
          position: 'absolute', left: 0, top: '50%',
          width: size * 1.6, height: size * 1.2,
          transform: 'translate(-50%, -50%)',
          background: `radial-gradient(ellipse at center, color-mix(in oklab, var(--accent) 35%, transparent) 0%, transparent 65%)`,
          pointerEvents: 'none', zIndex: 0,
        }} />
      )}
      <span style={{
        position: 'absolute', right: '100%', whiteSpace: 'pre',
        zIndex: 1,
      }}>{left}</span>
      <span ref={pinRef} style={{ color: 'var(--accent)', position: 'relative', zIndex: 1 }}>{pin}</span>
      <span style={{ zIndex: 1 }}>{right}</span>
    </div>
  );
}

// Pin-center guide lines: use a container that's pinned to the word's
// anchor (stage horizontal center = left edge of the pin char), then offset
// by half the pin character's width so the lines sit centered on the letter.
function GuideLines({ word, size }) {
  const { pin } = pinSplit(word);
  // Measure the pin char width with a hidden span so the line is exactly centered.
  const [w, setW] = React.useState(size * 0.35);
  const measureRef = React.useRef(null);
  React.useLayoutEffect(() => {
    if (measureRef.current) setW(measureRef.current.getBoundingClientRect().width);
  }, [pin, size]);
  return (
    <>
      {/* hidden measurer, matches ReaderWord font */}
      <span ref={measureRef} aria-hidden
        style={{
          position: 'absolute', visibility: 'hidden', pointerEvents: 'none',
          fontFamily: 'var(--font-reader)', fontWeight: 400, fontSize: size,
          letterSpacing: '0.005em', whiteSpace: 'pre',
        }}>{pin}</span>
      {/* Top guide: bottom edge sits above the word, vertically centered on 50% */}
      <div style={{
        position: 'absolute', left: `calc(50% + ${w/2}px)`, top: '50%',
        width: 1, height: 22, background: 'rgba(255,255,255,0.3)',
        transform: `translate(-0.5px, calc(-${size/2}px - 100%))`,
      }} />
      {/* Bottom guide: top edge sits below the word, vertically centered on 50% */}
      <div style={{
        position: 'absolute', left: `calc(50% + ${w/2}px)`, top: '50%',
        width: 1, height: 22, background: 'rgba(255,255,255,0.3)',
        transform: `translate(-0.5px, ${size/2}px)`,
      }} />
    </>
  );
}

function ReaderScreen({ variant = 'playing' }) {
  const ctx = React.useContext(window.TweakCtx || React.createContext({ tweaks: {} }));
  const t = ctx.tweaks || {};
  const word = variant === 'idle' ? 'beginning' : (variant === 'settings' ? 'anchor' : 'considered');
  const progress = variant === 'idle' ? 0 : (variant === 'settings' ? 0.48 : 0.34);
  const showGlow = t.readerGlow !== false && variant !== 'settings';
  const showGuides = t.guideLines !== false;

  return (
    <div style={{
      width: '100%', height: '100%', background: 'var(--reader)',
      position: 'relative', overflow: 'hidden',
    }}>
      <div style={{ height: 44 }} />

      <div style={{
        position: 'absolute', top: 52, left: 16, right: 16,
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      }}>
        <div style={{
          fontFamily: 'var(--font-mono)', fontSize: 8,
          letterSpacing: '0.28em', textTransform: 'uppercase',
          color: 'rgba(255,255,255,0.22)', fontWeight: 500,
          opacity: variant === 'idle' ? 1 : 0,
          transition: 'opacity 180ms',
        }}>
          tap · pause
        </div>
        <div style={{
          fontFamily: 'var(--font-mono)', fontSize: 9,
          letterSpacing: '0.12em',
          color: variant === 'playing' ? 'rgba(255,255,255,0.32)' : 'rgba(255,255,255,0.18)',
          fontWeight: 500,
        }}>
          {variant === 'idle' ? '17:20' : (variant === 'settings' ? '08:54' : '11:12')}
        </div>
      </div>

      {showGuides && <GuideLines word={word} size={54} />}

      <div style={{
        position: 'absolute', inset: 0,
        opacity: variant === 'settings' ? 0.55 : 1,
        transition: 'opacity 200ms',
      }}>
        <ReaderWord word={word} size={54} glow={showGlow} />
      </div>

      {variant === 'idle' && (
        <div style={{
          position: 'absolute', bottom: 46, left: '50%',
          transform: 'translateX(-50%)',
          padding: '8px 14px', borderRadius: 999,
          background: 'rgba(255,255,255,0.06)',
          border: '1px solid rgba(255,255,255,0.12)',
          backdropFilter: 'blur(8px)',
          fontFamily: 'var(--font-ui)', fontSize: 9.5, fontWeight: 500,
          letterSpacing: '0.22em', textTransform: 'uppercase',
          color: 'rgba(255,255,255,0.65)',
        }}>
          Paused — tap to start
        </div>
      )}

      <div style={{
        position: 'absolute', left: 0, right: 0, bottom: 0,
        height: 2, background: 'transparent',
      }}>
        <div style={{
          width: `${progress * 100}%`, height: '100%', background: 'var(--accent)',
        }} />
      </div>

      {variant === 'settings' && <ReaderSettingsDrawer />}
    </div>
  );
}

function ReaderSettingsDrawer() {
  return (
    <div style={{
      position: 'absolute', left: 6, right: 6, bottom: 0,
      background: 'rgba(22,22,28,0.96)', backdropFilter: 'blur(16px)',
      borderTopLeftRadius: 'var(--r-xl)', borderTopRightRadius: 'var(--r-xl)',
      borderTop: '1px solid var(--line-2)',
      borderLeft: '1px solid var(--line-2)',
      borderRight: '1px solid var(--line-2)',
      padding: '10px 20px 26px',
    }}>
      <div style={{
        width: 36, height: 3, background: 'var(--ink-3)', opacity: 0.5,
        borderRadius: 2, margin: '0 auto 16px',
      }} />

      <div style={{
        fontFamily: 'var(--font-mono)', fontSize: 9,
        letterSpacing: '0.28em', color: 'var(--ink-3)', fontWeight: 500,
      }}>
        READING
      </div>

      <div style={{ marginTop: 14 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
          <div style={{ fontFamily: 'var(--font-ui)', fontSize: 12, color: 'var(--ink-2)' }}>Speed</div>
          <div style={{
            fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--ink)', fontWeight: 500,
            letterSpacing: '0.04em',
          }}>420 WPM</div>
        </div>
        <Slider value={0.42} style={{ marginTop: 10 }} />
      </div>

      <div style={{ marginTop: 18 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
          <div style={{ fontFamily: 'var(--font-ui)', fontSize: 12, color: 'var(--ink-2)' }}>Size</div>
          <div style={{
            fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--ink)', fontWeight: 500,
            letterSpacing: '0.04em',
          }}>72 PX</div>
        </div>
        <Slider value={0.55} style={{ marginTop: 10 }} />
      </div>

      <div style={{
        fontFamily: 'var(--font-mono)', fontSize: 9,
        letterSpacing: '0.28em', color: 'var(--ink-3)', fontWeight: 500,
        marginTop: 22, marginBottom: 10,
      }}>
        PIN · CRIMSON
      </div>
      <div style={{ display: 'flex', gap: 10 }}>
        {['#D94050', '#E0A04A', '#6FAE6A', '#5C8AE6', '#F0F0F2'].map((c, i) => (
          <div key={i} style={{
            width: 24, height: 24, borderRadius: 'var(--r-sm)',
            background: c, border: '1px solid var(--line-2)',
            boxShadow: i === 0 ? '0 0 0 2px var(--accent)' : 'none',
          }} />
        ))}
        <div style={{
          width: 24, height: 24, borderRadius: 'var(--r-sm)',
          border: '1px dashed var(--line-2)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          color: 'var(--ink-3)',
        }}>
          <svg width="10" height="10" viewBox="0 0 10 10" fill="none"
            stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
            <path d="M5 1v8M1 5h8"/>
          </svg>
        </div>
      </div>
    </div>
  );
}

function Slider({ value = 0.5, style }) {
  return (
    <div style={{ position: 'relative', height: 12, ...style }}>
      <div style={{
        position: 'absolute', left: 0, right: 0, top: '50%',
        transform: 'translateY(-50%)',
        height: 2, background: 'var(--line-2)', borderRadius: 1,
      }} />
      <div style={{
        position: 'absolute', left: 0, top: '50%',
        transform: 'translateY(-50%)',
        height: 2, width: `${value*100}%`, background: 'var(--accent)', borderRadius: 1,
      }} />
      <div style={{
        position: 'absolute', top: '50%', left: `${value*100}%`,
        transform: 'translate(-50%, -50%)',
        width: 10, height: 10, borderRadius: 5,
        background: 'var(--accent)', border: '2px solid var(--reader)',
        boxShadow: '0 0 0 1px var(--accent)',
      }} />
    </div>
  );
}

window.ReaderScreen = ReaderScreen;
window.ReaderWord = ReaderWord;
window.Slider = Slider;
