// New Reading sheet over library
function NewReadingScreen() {
  return (
    <div style={{
      width: '100%', height: '100%', background: 'var(--stage)',
      position: 'relative', overflow: 'hidden',
    }}>
      {/* Dimmed library backdrop */}
      <div style={{ position: 'absolute', inset: 0, filter: 'blur(2px)', opacity: 0.35 }}>
        <LibraryScreen />
      </div>
      <div style={{ position: 'absolute', inset: 0, background: 'rgba(3,3,3,0.55)' }} />

      {/* Bottom sheet */}
      <div style={{
        position: 'absolute', left: 6, right: 6, bottom: 0,
        background: 'var(--surface-2)',
        borderTopLeftRadius: 'var(--r-xl)', borderTopRightRadius: 'var(--r-xl)',
        borderTop: '1px solid var(--line-2)',
        borderLeft: '1px solid var(--line-2)',
        borderRight: '1px solid var(--line-2)',
        paddingBottom: 30,
      }}>
        {/* Handle */}
        <div style={{
          width: 36, height: 3, background: 'var(--ink-3)', opacity: 0.5,
          borderRadius: 2, margin: '10px auto 18px',
        }} />

        {/* Title */}
        <div style={{ padding: '0 22px 6px' }}>
          <div style={{
            fontFamily: 'var(--font-display)', fontSize: 19, fontWeight: 400,
            color: 'var(--ink)', letterSpacing: '-0.02em',
          }}>
            New reading
          </div>
          <div style={{
            fontFamily: 'var(--font-ui)', fontSize: 11, fontWeight: 400,
            color: 'var(--ink-2)', marginTop: 3,
          }}>
            Choose a source.
          </div>
        </div>

        {/* Options */}
        <div style={{ marginTop: 20, padding: '0 22px' }}>
          {[
            {
              icon: (
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 013 3L7 19l-4 1 1-4L16.5 3.5z"/>
                </svg>
              ),
              title: 'Paste text',
              desc: 'Drop in anything from the clipboard',
              iconColor: 'var(--accent)',
              disabled: false,
            },
            {
              icon: (
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/>
                </svg>
              ),
              title: 'Upload PDF',
              desc: 'Text-based PDFs only for now',
              iconColor: 'var(--ink-2)',
              disabled: false,
            },
            {
              icon: (
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2a15.3 15.3 0 014 10 15.3 15.3 0 01-4 10A15.3 15.3 0 018 12a15.3 15.3 0 014-10z"/>
                </svg>
              ),
              title: 'From a URL',
              desc: 'Article extraction',
              iconColor: 'var(--ink-3)',
              disabled: true,
              badge: 'SOON',
            },
          ].map((row, i, arr) => (
            <div key={i} style={{
              display: 'flex', alignItems: 'center', gap: 14,
              padding: '14px 0',
              borderBottom: i < arr.length - 1 ? '1px solid var(--line)' : 'none',
              opacity: row.disabled ? 0.55 : 1,
            }}>
              <div style={{
                width: 36, height: 36, borderRadius: 'var(--r-sm)',
                background: 'var(--surface)', border: '1px solid var(--line-2)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                color: row.iconColor, flexShrink: 0,
              }}>
                {row.icon}
              </div>
              <div style={{ flex: 1 }}>
                <div style={{
                  fontFamily: 'var(--font-ui)', fontSize: 13, fontWeight: 500,
                  color: 'var(--ink)',
                }}>
                  {row.title}
                </div>
                <div style={{
                  fontFamily: 'var(--font-ui)', fontSize: 10.5, fontWeight: 400,
                  color: 'var(--ink-2)', marginTop: 2,
                }}>
                  {row.desc}
                </div>
              </div>
              {row.badge ? (
                <div style={{
                  fontFamily: 'var(--font-ui)', fontSize: 8.5, fontWeight: 500,
                  letterSpacing: '0.2em', color: 'var(--ink-3)',
                  border: '1px solid var(--line-2)', padding: '3px 6px',
                  borderRadius: 4,
                }}>{row.badge}</div>
              ) : (
                <svg width="10" height="14" viewBox="0 0 10 14" fill="none"
                  stroke="var(--ink-3)" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M2 1l6 6-6 6"/>
                </svg>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

window.NewReadingScreen = NewReadingScreen;
