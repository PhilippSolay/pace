// Phone bezel wrapper — minimal, matches brief's "300×620pt iPhone 15 Pro" spec
function PhoneFrame({ children, width = 300, height = 620 }) {
  return (
    <div style={{
      width, height, borderRadius: 44, overflow: 'hidden',
      position: 'relative', background: '#030303',
      boxShadow: '0 0 0 1px rgba(255,255,255,0.04), 0 40px 80px rgba(0,0,0,0.5)',
    }}>
      {/* Status bar */}
      <div style={{
        position: 'absolute', top: 0, left: 0, right: 0, height: 44,
        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        padding: '16px 24px 0', zIndex: 100, pointerEvents: 'none',
      }}>
        <div style={{
          fontFamily: '-apple-system, system-ui', fontSize: 13, fontWeight: 600,
          color: '#fff',
        }}>9:41</div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
          {/* signal */}
          <svg width="14" height="9" viewBox="0 0 14 9">
            <rect x="0" y="5.5" width="2.2" height="3.5" rx="0.5" fill="#fff"/>
            <rect x="3.4" y="3.5" width="2.2" height="5.5" rx="0.5" fill="#fff"/>
            <rect x="6.8" y="1.5" width="2.2" height="7.5" rx="0.5" fill="#fff"/>
            <rect x="10.2" y="0" width="2.2" height="9" rx="0.5" fill="#fff"/>
          </svg>
          {/* battery */}
          <svg width="20" height="10" viewBox="0 0 20 10">
            <rect x="0.5" y="0.5" width="17" height="9" rx="2" stroke="#fff" strokeOpacity="0.4" fill="none"/>
            <rect x="2" y="2" width="14" height="6" rx="1" fill="#fff"/>
            <rect x="18.5" y="3.5" width="1.2" height="3" rx="0.4" fill="#fff" fillOpacity="0.5"/>
          </svg>
        </div>
      </div>
      {/* Dynamic island */}
      <div style={{
        position: 'absolute', top: 8, left: '50%', transform: 'translateX(-50%)',
        width: 92, height: 28, borderRadius: 18, background: '#000', zIndex: 99,
      }} />
      {/* Content */}
      <div style={{ width: '100%', height: '100%' }}>{children}</div>
      {/* Home indicator */}
      <div style={{
        position: 'absolute', bottom: 6, left: '50%', transform: 'translateX(-50%)',
        width: 106, height: 4, borderRadius: 2,
        background: 'rgba(255,255,255,0.5)', zIndex: 100, pointerEvents: 'none',
      }} />
    </div>
  );
}

window.PhoneFrame = PhoneFrame;
