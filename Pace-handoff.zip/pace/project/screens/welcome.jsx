// Welcome / Sign In screen
function WelcomeScreen() {
  return (
    <div style={{
      width: '100%', height: '100%',
      background: 'var(--stage)',
      display: 'flex', flexDirection: 'column',
      paddingTop: 54, paddingBottom: 34, paddingLeft: 24, paddingRight: 24,
      boxSizing: 'border-box',
      position: 'relative',
      overflow: 'hidden',
    }}>
      {/* Hero */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center' }}>
        <div style={{
          fontFamily: 'var(--font-display)', fontWeight: 400,
          fontSize: 96, lineHeight: 1, letterSpacing: '-0.04em',
          color: 'var(--ink)', display: 'flex', alignItems: 'baseline',
        }}>
          Pace<span style={{ color: 'var(--accent)', fontStyle: 'italic', fontWeight: 300, marginLeft: -2 }}>.</span>
        </div>
        <div style={{
          fontFamily: 'var(--font-display)', fontStyle: 'italic', fontWeight: 300,
          fontSize: 16, color: 'var(--ink-2)', marginTop: 20,
          letterSpacing: '-0.01em',
        }}>
          Read one word at a time.
        </div>

        <div style={{ marginTop: 64, display: 'flex', gap: 14, alignItems: 'center' }}>
          {['FOCUSED', 'NO STREAKS', 'LOCAL-FIRST'].map((t, i) => (
            <React.Fragment key={t}>
              {i > 0 && <div style={{ width: 2, height: 2, borderRadius: '50%', background: 'var(--ink-3)' }} />}
              <div style={{
                fontFamily: 'var(--font-mono)', fontSize: 8.5,
                letterSpacing: '0.22em', color: 'var(--ink-3)', fontWeight: 500,
              }}>{t}</div>
            </React.Fragment>
          ))}
        </div>
      </div>

      {/* Action stack */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginBottom: 14 }}>
        <button style={{
          height: 44, borderRadius: 'var(--r-md)', border: 'none',
          background: 'var(--ink)', color: '#0A0A0A',
          fontFamily: 'var(--font-ui)', fontSize: 13, fontWeight: 500,
          display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
          cursor: 'pointer',
        }}>
          <svg width="13" height="15" viewBox="0 0 13 15" fill="currentColor">
            <path d="M10.5 11.8c-.5.8-1.2 1.6-2.1 1.6-.8 0-1-.5-1.9-.5s-1.2.5-1.9.5c-.9 0-1.5-.8-2.1-1.7C1.2 9.8.7 7.5 1.5 5.9c.7-1.4 2-2.1 3.2-2.1.9 0 1.3.5 2.2.5s1.2-.5 2.2-.5c1.1 0 2.3.6 3 1.8-2.6 1.4-2.2 5 .1 6.2zM7.7 2.8c.4-.5.7-1.2.6-1.9-.6 0-1.3.4-1.8.9-.4.4-.8 1.1-.7 1.8.7 0 1.4-.4 1.9-.8z"/>
          </svg>
          Continue with Apple
        </button>
        <button style={{
          height: 44, borderRadius: 'var(--r-md)',
          background: 'transparent', border: '1px solid var(--line-2)',
          color: 'var(--ink)', fontFamily: 'var(--font-ui)', fontSize: 13, fontWeight: 500,
          cursor: 'pointer',
        }}>
          Continue with email
        </button>
        <button style={{
          background: 'transparent', border: 'none', color: 'var(--ink-2)',
          fontFamily: 'var(--font-ui)', fontSize: 12, fontWeight: 400,
          padding: '12px 0 4px', cursor: 'pointer',
        }}>
          Use without an account
        </button>
      </div>

      <div style={{
        fontFamily: 'var(--font-ui)', fontSize: 9.5, color: 'var(--ink-3)',
        textAlign: 'center', lineHeight: 1.5, padding: '0 20px',
      }}>
        By continuing, you accept our <span style={{ color: 'var(--ink-2)', textDecoration: 'underline', textDecorationColor: 'var(--line-2)' }}>Terms</span> and <span style={{ color: 'var(--ink-2)', textDecoration: 'underline', textDecorationColor: 'var(--line-2)' }}>Privacy Notice</span>.
      </div>
    </div>
  );
}

window.WelcomeScreen = WelcomeScreen;
