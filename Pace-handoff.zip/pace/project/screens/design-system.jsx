// Design system reference tile
function DesignSystem() {
  const COLORS = [
    { tok: '--page-bg', val: '#030303', use: 'Page background' },
    { tok: '--stage', val: '#080809', use: 'App chrome' },
    { tok: '--reader', val: '#0A0A0A', use: 'Reader stage' },
    { tok: '--surface', val: '#101014', use: 'Primary surface' },
    { tok: '--surface-2', val: '#16161C', use: 'Elevated surface' },
    { tok: '--line', val: '#1E1E26', use: 'Hairline divider' },
    { tok: '--line-2', val: '#2A2A34', use: 'Border on elevated' },
    { tok: '--ink', val: '#F0F0F2', use: 'Primary text' },
    { tok: '--ink-2', val: '#9A9AA6', use: 'Secondary text' },
    { tok: '--ink-3', val: '#5A5A66', use: 'Tertiary text' },
    { tok: '--accent', val: '#D94050', use: 'Pin · accent' },
  ];
  return (
    <div style={{
      width: 1200, background: 'var(--stage)', color: 'var(--ink)',
      padding: 48, boxSizing: 'border-box',
      fontFamily: 'var(--font-ui)',
    }}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 24, marginBottom: 40 }}>
        <div style={{
          fontFamily: 'var(--font-display)', fontSize: 44, letterSpacing: '-0.03em',
          display: 'flex', alignItems: 'baseline',
        }}>
          Pace<span style={{ color: 'var(--accent)', fontStyle: 'italic', fontWeight: 300 }}>.</span>
        </div>
        <div style={{
          fontFamily: 'var(--font-mono)', fontSize: 10,
          letterSpacing: '0.28em', color: 'var(--ink-3)',
        }}>
          DESIGN SYSTEM · v1.0
        </div>
      </div>

      {/* Colors */}
      <div style={{ marginBottom: 48 }}>
        <div style={{
          fontFamily: 'var(--font-mono)', fontSize: 10,
          letterSpacing: '0.28em', color: 'var(--ink-3)', marginBottom: 16,
        }}>COLOR</div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14 }}>
          {COLORS.map(c => (
            <div key={c.tok} style={{
              background: 'var(--surface)', border: '1px solid var(--line-2)',
              borderRadius: 'var(--r-lg)', padding: 14, display: 'flex', gap: 12, alignItems: 'center',
            }}>
              <div style={{
                width: 44, height: 44, borderRadius: 'var(--r-sm)',
                background: c.val, border: '1px solid var(--line-2)', flexShrink: 0,
              }} />
              <div style={{ minWidth: 0 }}>
                <div style={{ fontFamily: 'var(--font-mono)', fontSize: 10.5, color: 'var(--ink)', letterSpacing: '0.04em' }}>
                  {c.tok}
                </div>
                <div style={{ fontFamily: 'var(--font-mono)', fontSize: 9, color: 'var(--ink-2)', marginTop: 2, letterSpacing: '0.04em' }}>
                  {c.val.toUpperCase()}
                </div>
                <div style={{ fontFamily: 'var(--font-ui)', fontSize: 10, color: 'var(--ink-3)', marginTop: 4 }}>
                  {c.use}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Typography */}
      <div style={{ marginBottom: 48 }}>
        <div style={{
          fontFamily: 'var(--font-mono)', fontSize: 10,
          letterSpacing: '0.28em', color: 'var(--ink-3)', marginBottom: 16,
        }}>TYPOGRAPHY</div>
        <div style={{
          background: 'var(--surface)', border: '1px solid var(--line-2)',
          borderRadius: 'var(--r-lg)', padding: '22px 26px',
          display: 'flex', flexDirection: 'column', gap: 14,
        }}>
          {[
            { family: 'EB Garamond', size: 44, weight: 400, sample: 'The reading surface. Anchored.', role: 'READER', stack: 'EB Garamond · 400' },
            { family: 'Fraunces', size: 28, weight: 400, italic: false, sample: 'Display titles and emphasis.', role: 'DISPLAY', stack: 'Fraunces · 300/400/500' },
            { family: 'Inter', size: 14, weight: 500, sample: 'UI labels, buttons, body copy.', role: 'UI', stack: 'Inter · 300/400/500/600' },
            { family: '"JetBrains Mono"', size: 11, weight: 500, sample: 'METADATA · NUMERALS · 420 WPM', role: 'MONO', stack: 'JetBrains Mono · 400/500' },
          ].map((t, i) => (
            <div key={i} style={{
              display: 'grid', gridTemplateColumns: '64px 1fr 160px', gap: 20, alignItems: 'baseline',
              paddingTop: i === 0 ? 0 : 14, borderTop: i === 0 ? 'none' : '1px solid var(--line)',
            }}>
              <div style={{
                fontFamily: 'var(--font-mono)', fontSize: 9,
                letterSpacing: '0.22em', color: 'var(--ink-3)',
              }}>{t.role}</div>
              <div style={{
                fontFamily: t.family + ', serif', fontSize: t.size, fontWeight: t.weight,
                color: 'var(--ink)', letterSpacing: t.family === 'Fraunces' ? '-0.02em' : 0,
              }}>
                {t.sample}
              </div>
              <div style={{
                fontFamily: 'var(--font-mono)', fontSize: 9.5,
                letterSpacing: '0.08em', color: 'var(--ink-2)', textAlign: 'right',
              }}>{t.stack}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Components */}
      <div style={{ marginBottom: 12 }}>
        <div style={{
          fontFamily: 'var(--font-mono)', fontSize: 10,
          letterSpacing: '0.28em', color: 'var(--ink-3)', marginBottom: 16,
        }}>COMPONENTS</div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 14 }}>
          {/* Buttons */}
          <div style={{ background: 'var(--surface)', border: '1px solid var(--line-2)', borderRadius: 'var(--r-lg)', padding: 20 }}>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: 9, letterSpacing: '0.22em', color: 'var(--ink-3)', marginBottom: 14 }}>BUTTONS</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              <button style={{ height: 44, borderRadius: 'var(--r-md)', border: 'none', background: 'var(--accent)', color: '#fff', fontFamily: 'var(--font-ui)', fontSize: 13, fontWeight: 500 }}>Primary</button>
              <button style={{ height: 44, borderRadius: 'var(--r-md)', background: 'transparent', border: '1px solid var(--line-2)', color: 'var(--ink)', fontFamily: 'var(--font-ui)', fontSize: 13, fontWeight: 500 }}>Secondary</button>
              <button style={{ height: 36, background: 'transparent', border: 'none', color: 'var(--ink-2)', fontFamily: 'var(--font-ui)', fontSize: 12, fontWeight: 400 }}>Ghost link</button>
            </div>
          </div>

          {/* Inputs */}
          <div style={{ background: 'var(--surface)', border: '1px solid var(--line-2)', borderRadius: 'var(--r-lg)', padding: 20 }}>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: 9, letterSpacing: '0.22em', color: 'var(--ink-3)', marginBottom: 14 }}>INPUT</div>
            <div style={{
              height: 40, borderRadius: 'var(--r-md)', background: 'var(--surface-2)',
              border: '1px solid var(--accent)', display: 'flex', alignItems: 'center',
              padding: '0 12px', fontFamily: 'var(--font-ui)', fontSize: 13,
              color: 'var(--ink)', marginBottom: 10,
            }}>anna@mail.com</div>
            <div style={{
              height: 40, borderRadius: 'var(--r-md)', background: 'var(--surface-2)',
              border: '1px solid var(--line-2)', display: 'flex', alignItems: 'center',
              padding: '0 12px', fontFamily: 'var(--font-ui)', fontSize: 13,
              color: 'var(--ink-3)', fontStyle: 'italic',
            }}>Title (optional)</div>
          </div>

          {/* Toggle + slider */}
          <div style={{ background: 'var(--surface)', border: '1px solid var(--line-2)', borderRadius: 'var(--r-lg)', padding: 20 }}>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: 9, letterSpacing: '0.22em', color: 'var(--ink-3)', marginBottom: 14 }}>CONTROLS</div>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }}>
              <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
                <Toggle on />
                <Toggle />
              </div>
            </div>
            <Slider value={0.55} />
          </div>
        </div>

        {/* Swatches + chips row */}
        <div style={{ marginTop: 14, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
          <div style={{ background: 'var(--surface)', border: '1px solid var(--line-2)', borderRadius: 'var(--r-lg)', padding: 20 }}>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: 9, letterSpacing: '0.22em', color: 'var(--ink-3)', marginBottom: 14 }}>PIN SWATCHES</div>
            <div style={{ display: 'flex', gap: 10 }}>
              {[
                { c: '#D94050', active: true }, { c: '#E0A04A' }, { c: '#6FAE6A' },
                { c: '#5C8AE6' }, { c: '#F0F0F2' },
              ].map((s, i) => (
                <div key={i} style={{
                  width: 28, height: 28, borderRadius: 'var(--r-sm)', background: s.c,
                  border: '1px solid var(--line-2)',
                  boxShadow: s.active ? '0 0 0 2px var(--accent)' : 'none',
                }} />
              ))}
            </div>
          </div>
          <div style={{ background: 'var(--surface)', border: '1px solid var(--line-2)', borderRadius: 'var(--r-lg)', padding: 20 }}>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: 9, letterSpacing: '0.22em', color: 'var(--ink-3)', marginBottom: 14 }}>PIN RULE</div>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 18 }}>
              <div style={{ fontFamily: 'var(--font-reader)', fontSize: 30, color: 'var(--ink)' }}>
                consider<span style={{ color: 'var(--accent)' }}>e</span>d
              </div>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--ink-2)', letterSpacing: '0.08em' }}>
                pin = ceil(len ÷ 2) · 1-indexed
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

window.DesignSystem = DesignSystem;
