// Library screen
const LIB_TEXTS = [
  { title: 'The Crack-Up', source: 'F. Scott Fitzgerald', words: 4280, mins: 17, progress: 0.34 },
  { title: 'On the Phenomenon of Bullshit Jobs', source: 'Strike! Magazine', words: 2960, mins: 12, progress: 0 },
  { title: 'Notes on Nationalism', source: 'George Orwell', words: 7120, mins: 28, progress: 0.82 },
  { title: 'The Death of the Moth', source: 'Virginia Woolf', words: 1420, mins: 6, progress: 1 },
  { title: 'Slouching Towards Bethlehem', source: 'Joan Didion', words: 9340, mins: 37, progress: 0 },
  { title: 'Politics and the English Language', source: 'George Orwell', words: 5280, mins: 21, progress: 0 },
  { title: 'The White Album', source: 'Joan Didion', words: 6120, mins: 24, progress: 0 },
];

function LibraryScreen({ showDeleteOn = null }) {
  const cont = LIB_TEXTS[0];
  return (
    <div style={{
      width: '100%', height: '100%', background: 'var(--stage)',
      display: 'flex', flexDirection: 'column', position: 'relative',
      overflow: 'hidden',
    }}>
      {/* Status bar spacer */}
      <div style={{ height: 44, flexShrink: 0 }} />

      {/* Header */}
      <div style={{
        display: 'flex', alignItems: 'baseline', justifyContent: 'space-between',
        padding: '12px 20px 20px', flexShrink: 0,
      }}>
        <div style={{
          fontFamily: 'var(--font-display)', fontWeight: 400, fontSize: 26,
          color: 'var(--ink)', letterSpacing: '-0.03em',
          display: 'flex', alignItems: 'baseline',
        }}>
          Pace<span style={{ color: 'var(--accent)', fontStyle: 'italic', fontWeight: 300 }}>.</span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
          <div style={{
            fontFamily: 'var(--font-ui)', fontSize: 9.5,
            letterSpacing: '0.2em', color: 'var(--ink-3)', fontWeight: 500,
          }}>
            7 TEXTS
          </div>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
            stroke="var(--ink-2)" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
            <circle cx="12" cy="12" r="3"/>
            <path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 11-2.83 2.83l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 11-4 0v-.09a1.65 1.65 0 00-1-1.51 1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 11-2.83-2.83l.06-.06a1.65 1.65 0 00.33-1.82 1.65 1.65 0 00-1.51-1H3a2 2 0 110-4h.09a1.65 1.65 0 001.51-1 1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 112.83-2.83l.06.06a1.65 1.65 0 001.82.33h0a1.65 1.65 0 001-1.51V3a2 2 0 114 0v.09a1.65 1.65 0 001 1.51h0a1.65 1.65 0 001.82-.33l.06-.06a2 2 0 112.83 2.83l-.06.06a1.65 1.65 0 00-.33 1.82v0a1.65 1.65 0 001.51 1H21a2 2 0 110 4h-.09a1.65 1.65 0 00-1.51 1z"/>
          </svg>
        </div>
      </div>

      {/* Scrollable content */}
      <div style={{ flex: 1, overflow: 'auto', padding: '0 20px 100px' }}>
        {/* Continue reading card */}
        <div style={{
          background: 'linear-gradient(145deg, #1A1418 0%, #0F0A0C 100%)',
          borderRadius: 'var(--r-lg)', border: '1px solid var(--line-2)',
          padding: 14, position: 'relative', overflow: 'hidden',
        }}>
          <div style={{
            position: 'absolute', left: 0, top: 0, bottom: 0, width: 3,
            background: 'var(--accent)',
          }} />
          <div style={{
            fontFamily: 'var(--font-ui)', fontSize: 8,
            letterSpacing: '0.2em', color: 'var(--accent)', fontWeight: 500,
            textTransform: 'uppercase',
          }}>
            Continue reading
          </div>
          <div style={{
            fontFamily: 'var(--font-display)', fontSize: 15, fontWeight: 400,
            color: 'var(--ink)', marginTop: 10, letterSpacing: '-0.01em',
          }}>
            {cont.title}
          </div>
          <div style={{ display: 'flex', alignItems: 'center', marginTop: 12, gap: 10 }}>
            <div style={{ flex: 1, height: 2, background: 'var(--line-2)', borderRadius: 1, overflow: 'hidden' }}>
              <div style={{ width: `${cont.progress*100}%`, height: '100%', background: 'var(--accent)' }} />
            </div>
            <div style={{
              fontFamily: 'var(--font-ui)', fontSize: 9,
              color: 'var(--ink-2)', letterSpacing: '0.08em', fontWeight: 500,
            }}>
              {Math.round(cont.progress*100)}% · {Math.round(cont.mins*(1-cont.progress))} MIN LEFT
            </div>
          </div>
        </div>

        {/* Library eyebrow */}
        <div style={{
          fontFamily: 'var(--font-ui)', fontSize: 9.5,
          letterSpacing: '0.28em', color: 'var(--ink-3)', fontWeight: 500,
          marginTop: 32, marginBottom: 4, paddingLeft: 2,
        }}>
          LIBRARY
        </div>

        {/* List */}
        <div>
          {LIB_TEXTS.slice(1).map((t, i) => {
            const showDelete = showDeleteOn === i;
            return (
              <div key={i} style={{
                position: 'relative', borderBottom: '1px solid var(--line)',
                overflow: 'hidden',
              }}>
                <div style={{
                  padding: '12px 2px',
                  transform: showDelete ? 'translateX(-78px)' : 'translateX(0)',
                  transition: 'transform 180ms ease',
                }}>
                  <div style={{
                    fontFamily: 'var(--font-display)', fontSize: 13.5, fontWeight: 400,
                    color: t.progress === 1 ? 'var(--ink-2)' : 'var(--ink)',
                    letterSpacing: '-0.005em',
                  }}>
                    {t.title}
                  </div>
                  <div style={{
                    fontFamily: 'var(--font-ui)', fontSize: 9, fontWeight: 500,
                    color: 'var(--ink-2)', marginTop: 4, letterSpacing: '0.08em',
                    display: 'flex', alignItems: 'center', gap: 6,
                  }}>
                    <span>{t.source.toUpperCase()}</span>
                    <span style={{ color: 'var(--ink-3)' }}>·</span>
                    <span>{t.words.toLocaleString()} WORDS</span>
                    <span style={{ color: 'var(--ink-3)' }}>·</span>
                    <span>{t.mins} MIN</span>
                    {t.progress === 1 && <>
                      <span style={{ color: 'var(--ink-3)' }}>·</span>
                      <span style={{ color: 'var(--accent)' }}>READ</span>
                    </>}
                  </div>
                  {t.progress > 0 && t.progress < 1 && (
                    <div style={{
                      height: 1, background: 'var(--line-2)',
                      marginTop: 8, position: 'relative',
                    }}>
                      <div style={{
                        width: `${t.progress*100}%`, height: '100%',
                        background: 'var(--accent)', opacity: 0.8,
                      }} />
                    </div>
                  )}
                </div>
                {showDelete && (
                  <div style={{
                    position: 'absolute', right: 0, top: 0, bottom: 1,
                    width: 78, background: 'var(--accent)',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    color: '#fff', fontFamily: 'var(--font-ui)', fontSize: 12, fontWeight: 500,
                  }}>
                    Delete
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* FAB */}
      <button style={{
        position: 'absolute', right: 20, bottom: 34,
        width: 48, height: 48, borderRadius: 'var(--r-fab)', border: 'none',
        background: 'var(--accent)', color: '#fff', cursor: 'pointer',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        boxShadow: '0 8px 24px rgba(217,64,80,0.3), 0 2px 6px rgba(0,0,0,0.5)',
      }}>
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none"
          stroke="currentColor" strokeWidth="1.8" strokeLinecap="round">
          <path d="M12 5v14M5 12h14"/>
        </svg>
      </button>
    </div>
  );
}

window.LibraryScreen = LibraryScreen;
