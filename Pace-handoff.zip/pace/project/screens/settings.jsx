// Settings screen
function Toggle({ on = false }) {
  return (
    <div style={{
      width: 28, height: 16, borderRadius: 'var(--r-sm)',
      background: on ? 'var(--accent)' : 'var(--line-2)',
      position: 'relative', transition: 'background 150ms ease',
      flexShrink: 0,
    }}>
      <div style={{
        position: 'absolute', top: 2, left: on ? 14 : 2,
        width: 12, height: 12, borderRadius: 'var(--r-sm)',
        background: '#fff', transition: 'left 150ms ease',
      }} />
    </div>
  );
}

function SettingRow({ label, right, last }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      height: 44, borderBottom: last ? 'none' : '1px solid var(--line)',
    }}>
      <div style={{
        fontFamily: 'var(--font-ui)', fontSize: 13, fontWeight: 400,
        color: 'var(--ink)',
      }}>
        {label}
      </div>
      <div>{right}</div>
    </div>
  );
}

function Eyebrow({ children, style }) {
  return (
    <div style={{
      fontFamily: 'var(--font-mono)', fontSize: 9,
      letterSpacing: '0.28em', color: 'var(--ink-3)', fontWeight: 500,
      marginBottom: 10, ...style,
    }}>
      {children}
    </div>
  );
}

function SettingsScreen() {
  return (
    <div style={{
      width: '100%', height: '100%', background: 'var(--stage)',
      display: 'flex', flexDirection: 'column', overflow: 'hidden',
    }}>
      <div style={{ height: 44 }} />

      {/* Header */}
      <div style={{ padding: '10px 20px 16px', display: 'flex', alignItems: 'center', gap: 12 }}>
        <svg width="9" height="15" viewBox="0 0 9 15" fill="none"
          stroke="var(--ink-2)" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
          <path d="M7.5 1.5L1.5 7.5l6 6"/>
        </svg>
        <div style={{
          fontFamily: 'var(--font-display)', fontSize: 22, fontWeight: 400,
          color: 'var(--ink)', letterSpacing: '-0.02em',
        }}>
          Settings
        </div>
      </div>

      <div style={{ flex: 1, overflow: 'auto', padding: '4px 20px 80px' }}>
        {/* Account */}
        <Eyebrow>ACCOUNT</Eyebrow>
        <div>
          <SettingRow
            label={<>
              <div style={{ fontSize: 13, color: 'var(--ink)' }}>anna.fielding@mail.com</div>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: 9, color: 'var(--ink-2)', marginTop: 2, letterSpacing: '0.12em' }}>PACE · LOCAL</div>
            </>}
            right={null}
          />
          <SettingRow
            label={<span style={{ color: 'var(--ink-2)' }}>Sign out</span>}
            right={null}
            last
          />
        </div>

        {/* Reading */}
        <div style={{ marginTop: 28 }}>
          <Eyebrow>READING</Eyebrow>
          <div style={{ padding: '10px 0', borderBottom: '1px solid var(--line)' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
              <div style={{ fontFamily: 'var(--font-ui)', fontSize: 13, color: 'var(--ink)' }}>Default speed</div>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--ink-2)', letterSpacing: '0.04em' }}>380 WPM</div>
            </div>
            <Slider value={0.36} style={{ marginTop: 10 }} />
          </div>
          <div style={{ padding: '10px 0', borderBottom: '1px solid var(--line)' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
              <div style={{ fontFamily: 'var(--font-ui)', fontSize: 13, color: 'var(--ink)' }}>Default font size</div>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--ink-2)', letterSpacing: '0.04em' }}>68 PX</div>
            </div>
            <Slider value={0.38} style={{ marginTop: 10 }} />
          </div>
          <SettingRow
            label="Default font"
            right={<div style={{
              fontFamily: 'var(--font-ui)', fontSize: 12, color: 'var(--ink-2)',
              display: 'flex', alignItems: 'center', gap: 6,
            }}>
              <span style={{ fontFamily: 'var(--font-reader)', fontSize: 14, color: 'var(--ink)' }}>EB Garamond</span>
              <svg width="10" height="14" viewBox="0 0 10 14" fill="none"
                stroke="var(--ink-3)" strokeWidth="1.6" strokeLinecap="round"><path d="M2 1l6 6-6 6"/></svg>
            </div>}
            last
          />
        </div>

        {/* Appearance */}
        <div style={{ marginTop: 28 }}>
          <Eyebrow>APPEARANCE</Eyebrow>

          {/* Preview tile */}
          <div style={{
            height: 100, borderRadius: 'var(--r-lg)',
            background: 'var(--reader)', border: '1px solid var(--line-2)',
            position: 'relative', overflow: 'hidden', marginBottom: 14,
          }}>
            <div style={{
              position: 'absolute', inset: 0,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              <ReaderWord word="preview" size={28} glow />
            </div>
            <div style={{
              position: 'absolute', left: 10, top: 10,
              fontFamily: 'var(--font-mono)', fontSize: 8,
              letterSpacing: '0.22em', color: 'rgba(255,255,255,0.3)',
            }}>PREVIEW</div>
          </div>

          {[
            { label: 'Background', color: '#0A0A0A' },
            { label: 'Text', color: '#F0F0F2' },
            { label: 'Pin', color: '#D94050' },
          ].map((c, i, a) => (
            <SettingRow key={c.label} label={c.label} last={i === a.length - 1}
              right={<div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <div style={{
                  fontFamily: 'var(--font-mono)', fontSize: 10,
                  color: 'var(--ink-2)', letterSpacing: '0.06em',
                }}>{c.color.toUpperCase()}</div>
                <div style={{
                  width: 24, height: 24, borderRadius: 'var(--r-sm)',
                  background: c.color, border: '1px solid var(--line-2)',
                }} />
              </div>}
            />
          ))}
        </div>

        {/* Behavior */}
        <div style={{ marginTop: 28 }}>
          <Eyebrow>BEHAVIOR</Eyebrow>
          <SettingRow label="Highlight pinned character" right={<Toggle on />} />
          <SettingRow label="Show center guide lines" right={<Toggle on />} />
          <SettingRow label="Punctuation pauses" right={<Toggle />} />
          <SettingRow label="Haptics" right={<Toggle on />} last />
        </div>

        {/* Data */}
        <div style={{ marginTop: 28 }}>
          <Eyebrow>DATA</Eyebrow>
          <SettingRow label="Export library" right={
            <svg width="10" height="14" viewBox="0 0 10 14" fill="none"
              stroke="var(--ink-3)" strokeWidth="1.6" strokeLinecap="round"><path d="M2 1l6 6-6 6"/></svg>
          } />
          <SettingRow label={<span style={{ color: 'var(--accent)' }}>Clear all data</span>} right={null} last />
        </div>

        {/* About */}
        <div style={{ marginTop: 28 }}>
          <Eyebrow>ABOUT</Eyebrow>
          <SettingRow label="Version" right={<div style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--ink-2)', letterSpacing: '0.04em' }}>1.0.0 · 240</div>} />
          <SettingRow label="Privacy policy" right={
            <svg width="10" height="14" viewBox="0 0 10 14" fill="none"
              stroke="var(--ink-3)" strokeWidth="1.6" strokeLinecap="round"><path d="M2 1l6 6-6 6"/></svg>
          } />
          <SettingRow label="Terms" right={
            <svg width="10" height="14" viewBox="0 0 10 14" fill="none"
              stroke="var(--ink-3)" strokeWidth="1.6" strokeLinecap="round"><path d="M2 1l6 6-6 6"/></svg>
          } />
          <SettingRow label="Acknowledgements" last right={
            <svg width="10" height="14" viewBox="0 0 10 14" fill="none"
              stroke="var(--ink-3)" strokeWidth="1.6" strokeLinecap="round"><path d="M2 1l6 6-6 6"/></svg>
          } />
        </div>
      </div>
    </div>
  );
}

window.SettingsScreen = SettingsScreen;
window.Toggle = Toggle;
window.Eyebrow = Eyebrow;
